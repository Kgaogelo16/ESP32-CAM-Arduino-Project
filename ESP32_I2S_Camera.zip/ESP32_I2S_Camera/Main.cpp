#include "OV7670.h"
#include "BMP.h"


#define echoPin 26               // CHANGE PIN NUMBER HERE IF YOU WANT TO USE A DIFFERENT PIN
#define trigPin 25             // CHANGE PIN NUMBER HERE IF YOU WANT TO USE A DIFFERENT PIN
#define LedPin 0
int sensetivity = 10;
int prevDist = 0;

const int SIOD = 21; //SDA
const int SIOC = 22; //SCL

const int VSYNC = 34; 
const int HREF = 35;

const int XCLK = 32;
const int PCLK = 33;

const int D0 = 27;
const int D1 = 17;
const int D2 = 16;
const int D3 = 15;
const int D4 = 14;
const int D5 = 13;
const int D6 = 12;
const int D7 = 4;

const int TFT_DC = 2;
const int TFT_CS = 5;
//DIN <- MOSI 23
//CLK <- SCK 18

//#define ssid1        "YOUR_WIFI_SSID"
//#define password1    "YOUR_PASSWORD"
//#define ssid2        ""
//#define password2    ""
long duration, distance;

OV7670 *camera;


unsigned char bmpHeader[BMP::headerSize];


void setup() 
{
  Serial.begin (115200);
  camera = new OV7670(OV7670::Mode::QQVGA_RGB565, SIOD, SIOC, VSYNC, HREF, XCLK, PCLK, D0, D1, D2, D3, D4, D5, D6, D7);
  BMP::construct16BitHeader(bmpHeader, camera->xres, camera->yres);
  
  pinMode(trigPin, OUTPUT);
  pinMode(echoPin, INPUT);
  pinMode(LedPin,OUTPUT);
}


void CapturePic(){
  camera->oneFrame();
  BMP::construct16BitHeader(bmpHeader, camera->xres, camera->yres);
 Serial.println("BMP_START");

  // Send BMP header
  Serial.write(bmpHeader, BMP::headerSize);

  // Send pixel data (bottom-up as BMP expects)
  for (int row = camera->yres - 1; row >= 0; row--) {
    int offset = row * camera->xres * 2; // 2 bytes per pixel (RGB565)
    Serial.write(camera->frame + offset, camera->xres * 2);
  }

  Serial.println("BMP_END");
  Serial.println("\n};");

  for(int k = 0; k < 3;k++){
    Serial.print("IN IMAGE CAPTURE");
     bool j = IsMovement();
     Serial.print("OUT IMAGE CAPTURE");
  }
  delay(2300);

}


bool IsMovement(){
  bool isMoving = false;
  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);
  
  duration = pulseIn(echoPin, HIGH);
  distance = duration / 58.2;
  String disp = String(distance);

  Serial.print("Distance: ");
  Serial.print(disp);
  Serial.println(" cm");

  if(abs(distance - prevDist) > sensetivity){
     digitalWrite(LedPin, HIGH);
      Serial.println("Movement detected");
      isMoving  = true;
  }else{
    digitalWrite(LedPin, LOW);
  }
  prevDist = distance;
  return isMoving;
}



void loop()
{
   
  if(IsMovement()){
    Serial.print("Take Picture");
    CapturePic();
  }

  
  
  delay(200);

}
